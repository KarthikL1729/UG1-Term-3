# Lecture 13 Notes

# Key Ideas

1. Variance
2. Examples and Properties of Discrete Random Variables
3. Examples and Properties of Continuous Random Variables

---

## Variance of a Random Variable

Given a r.v X, its variance is given by

$Var(X) = E[(X - E(X))^2] = E(X^2) - (E(X))^2$

If X is discrete, then

$E(X) = \mu\ \ \ Var(X) = \sum_{x_i}(x_i-\mu)^2P_X(x_i)$

If X is continuous, then

$E(X) = \mu\ \ \ Var(X) = \int_{-\infin}^{\infin}(x-\mu)^2f_X(x)dx$

### Properties of Variance

Variance is always $\geq0$, with equality iff the random variable is constant.

---

## Examples of Discrete Random Variables

### 1. Bernoulli Random Variables

- Defined by

    $P_X(x) = \begin{cases}p & for \ x=1\\1-p & for\ x=0\\0 & otherwise\end{cases}$

     

- $E(X) = 0(1-p) + 1(p) = p$
- $Var(X) = (0-p)^2(1-p) + (1-p)^2(p) = p(1-p)$

    ![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-12-43.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-12-43.png)

### 2. Binomial Random Variables

- Experiment: Biased coin tossed k times with probability of heads being p; outcomes mapped to n where n is the number of heads obtained.
- $E(X) = \sum_{i=0}^{n}i{n \choose i}p^i(1-p)^{n-i} = np$
- $Var(X) =$  Sum of variances of n Bernoulli variables $=nVar(X) = np(1-p)$

    ![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-12-57.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-12-57.png)

### 3. Geometric Random Variables

- Experiment: Toss a biased coin till a head is obtained. X is the position of the head.
- $P_X(k) = (1-p)^{k-1}p$
- $E(X) = \sum_{i=0}^{n}i(1-p)^{i-1}p = 1/p$
- $Var(X) =$  $E(X^2) - (E(X))^2=E(X^2) -1/p^2$

    $E(X^2) = \sum_{k=1}^{\infin}k^2p(1-p)^{k-1}=(2-p)/p^2$

 

- $\therefore Var(X) = (2-p-1)/p^2 = (1-p)/p^2$

    ![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-12-50.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-12-50.png)

### 4. Poisson Random Variables

- Used to model rare events
- $P_X(k) = \lambda^ke^{-\lambda}/k!$
- $E(X) = \lambda$
- $Var(X) =\lambda$

    ![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-13-10.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-13-10.png)

---

## Examples of Continuous Random Variables

### 1. Uniform Random Variables

- $f_X(x) = \begin{cases}1/(b-a) & for \ a\leq x\leq b\\0 & otherwise\end{cases}$
- $E(X) = (a+b)/2$
- $Var(X) = (b-a)^2/2$

![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-02-44.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-02-44.png)

 

### 2. Exponential Random Variables

- Used to model completion time
- $f_X(x) = \begin{cases}\lambda e^{-\lambda x} & for x\geq 0\\0 & otherwise\end{cases}$
- $E(X) = \int_{0}^{\infin}x\lambda e^{-\lambda x}dx=1/\lambda$
- $Var(X) = 1/\lambda ^2$

    ![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-06-49.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-06-49.png)

### 3. Gaussian Random Variables

- Used to model noise. It is a sum of many independent R.V.s
- $f_X(x) = \frac{1}{\sqrt{2\pi \sigma ^2}}e^\frac{-(x-\mu)^2}{2\sigma ^2}$
- $E(X) = \mu$
- $Var(X) = \sigma ^2$

    ![Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-11-46.png](Lecture%2013%20Notes%20e842fef9a3e0449fa78bac59b75dbc5c/Screenshot_from_2021-08-06_23-11-46.png)

    ---